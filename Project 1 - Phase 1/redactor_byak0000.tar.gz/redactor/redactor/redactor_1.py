#!/usr/bin/python
import sys
import subprocess
import re
import glob
import nltk
import PyPDF2
from geotext import GeoText
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch, cm
from itertools import chain
from nltk.corpus import wordnet
from nltk import sent_tokenize
from nltk import word_tokenize
from bs4 import BeautifulSoup
from nltk.chunk.util import (ChunkScore, accuracy, tagstr2tree, conllstr2tree,
                             conlltags2tree, tree2conlltags, tree2conllstr, tree2conlltags,
                             ieerstr2tree)
from nltk.chunk.regexp import RegexpChunkParser, RegexpParser



def redact_phones(content):
    phones_re = re.compile("\+?\d?-?\d{3}-?\d{3}-?\d{4}|\+?\d{2}?-?\d{3}-?\d{3}-?\d{2}-?\d{2}|\+?\d{2}?-?\d{3}\s\d{7}|\+?\d?\s?\(?\d{3}\)?\s\d{2}\s\d{2}\s\d{3}|\+?\d?\s?\(?\d{3}\)?\s?\d{2}-?\d{2}\s?\d{3}|\+?\d{2}?\.?\d{3}\.?\d{3}\.?\d{4}|\+?\d?\/?\d{3}\/?\d{3}\/?\d{4}|\+?\d{2}?\d{10}", re.IGNORECASE)
    phones = phones_re.findall(content)
    #print(phones)
    for n in phones:
        content = content.replace(n,'####')
    return content


def redact_concept(content,concept):
    cont_sent = nltk.sent_tokenize(content)
    syn_word = wordnet.synsets(concept)
    syn_concept = set(chain.from_iterable([word.lemma_names() for word in syn_word]))
    #print(syn_concept)
    for sent in cont_sent:
        #for word in nltk.word_tokenize(sent):
        if any(item in sent.lower() for item in syn_concept):
           content = content.replace(sent,'++++')
    #print(content)
    return content

def redact_gender(content):
    #print(content)
    #cont_sent = nltk.sent_tokenize(content)
    gender_list = ['him','her','himself','herself','male','female','his','she','man','woman','men','women']
    #for sent in cont_sent:
    for word in content.split():
        word = re.sub('[,\.]','',word)
        for g in gender_list:
            if word.lower() == g and re.match('^'+re.escape(word.lower())+'$',g) is not None:
               #print(word)
               content = content.replace(word, '----')
    new_content = re.sub(r"\bhe\b","----",content)
    new_1_content = re.sub(r"\bHe\b","----",new_content)
    new_2_content = re.sub(r"\bHE\b","----",new_1_content)
    return new_2_content


def redact_name_loc(content,n_o_l):
    cont_sent = nltk.sent_tokenize(content)
    cont_word_tok = [nltk.word_tokenize(sent) for sent in cont_sent]
    cont_word_tok_tag = [nltk.pos_tag(word) for word in cont_word_tok]
    cont_chunks = nltk.ne_chunk_sents(cont_word_tok_tag, binary = False)
    #for c in cont_chunks:
     #   print(c)
    n_list,l_list = find_names_loc(cont_chunks)
    if (n_o_l == "--names"):
        for n in n_list:
           content = content.replace(n,'****')
    if (n_o_l == "--places"):
        for n in l_list:
           content = content.replace(n,'****')
    #print(content)
    return content

def find_names_loc(cont_chunks):
    name_list=[]
    loc_list=[]
    #print(n_l_l)
    for chunk in cont_chunks:
        if hasattr(chunk, 'label') and chunk.label:
           if chunk.label() == 'PERSON':
              name_loc_list.append(' '.join([chunks[0] for chunks in chunk]))
           if (chunk.label() == 'LOCATION' or chunk.label() == 'GPE'):
               loc_list.append(' '.join([each_1[0] for each_1 in each]))
           else:
              for each in chunk:
                  if hasattr(each,'label') and each.label:
                      if (each.label() == 'PERSON'):
                          name_list.append(' '.join([each_1[0] for each_1 in each]))
                      if (each.label() == 'GPE'):
                          loc_list.append(' '.join([each_1[0] for each_1 in each]))
    return name_list,loc_list


def search_tag(argv,tag):
    #print(argv)
    for s_tag in argv:
        #print(s_tag)
        if s_tag == tag:
           #print (s_tag)
           return 1
    return 0



if __name__ == "__main__":
  text_files = glob.glob(sys.argv[4],recursive = True)
  html_files = glob.glob(sys.argv[2],recursive = True)
  argv_list = sys.argv
  conc=''
  out_loc=''
  if search_tag(argv_list,"--output") == 1:
     for i in range(len(argv_list)):
         if argv_list[i] == "--output":
            out_loc = argv_list[i+1]
            subprocess.run("""mkdir %s""" %(out_loc) ,shell=True,stdout=subprocess.PIPE,universal_newlines=True)
#print(argv_list)
  if len(html_files) == 0:
     print("There are no html files available")
  else: 
       for file_name in html_files:
           html_file_ptr = open(file_name,'r')
           html_file_cont = html_file_ptr.read()
           raw = BeautifulSoup(html_file_cont,'lxml')
           filedata = raw.text
           if search_tag(argv_list,"--concept") == 1:
              for i in range(len(argv_list)):
                  if argv_list[i] == "--concept":
                     conc = argv_list[i+1]
              filedata = redact_concept(filedata,conc)
           if search_tag(argv_list,"--phones") == 1:
              #print("in the phones")
              filedata = redact_phones(filedata)
           if search_tag(argv_list,"--genders") == 1:
              filedata = redact_gender(filedata)
           if search_tag(argv_list,"--names") == 1:
              #print("In Names and Places")
              filedata = redact_name_loc(filedata,"--names")
           if search_tag(argv_list,"--places") == 1:
              #print("In Names and Places")
              filedata = redact_name_loc(filedata,"--places")
           if search_tag(argv_list,"--output") == 1:
              abs_file_name = out_loc + file_name
              #y = PdfWriter()
              #y.addBlankPage(200,200)
              #ops = file(filedata, "wb")
              #y.write(ops)
              #ops.close()
              with open(abs_file_name.strip('.html') + ".pdf" , 'w') as pdf_f:
                   pdf_f.write(filedata)

  if len(text_files) == 0:
     print("There are no text files available in otherfiles directory")
  else:
       for file_name in text_files:
           txt_file_ptr = open(file_name,'r')
           filedata = txt_file_ptr.read()
           if search_tag(argv_list,"--concept") == 1:
              #print("In COncept")
              for i in range(len(argv_list)):
                  if argv_list[i] == "--concept":
                     conc = argv_list[i+1]
              filedata = redact_concept(filedata,conc)
              
           if search_tag(argv_list,"--genders") == 1:
              #print("In Gender")
              filedata = redact_gender(filedata)
           if search_tag(argv_list,"--phones") == 1:
              #print("in the phones")
              filedata = redact_phones(filedata)
           if search_tag(argv_list,"--names") == 1:
              #print("In Names and Places")
              filedata = redact_name_loc(filedata,"--names")
           if search_tag(argv_list,"--places") == 1:
              #print("In Names and Places")
              filedata = redact_name_loc(filedata,"--places")
           print(filedata)
           if search_tag(argv_list,"--output") == 1:
              #print("In OUTPUT")
              abs_file_name = out_loc + file_name
              new_abs_file_name = re.sub(r"\b/otherfiles\b","",abs_file_name)
              #c = canvas.Canvas('ex.pdf')
              #print(new_abs_file_name)
              with open(new_abs_file_name.strip('.txt') + ".pdf" , 'w') as pdf_f:
                   pdf_f.write(filedata)
