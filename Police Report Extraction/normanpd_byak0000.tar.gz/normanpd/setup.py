from setuptools import setup, find_packages
setup(
name='CS 5970 | Activity Police Report Extraction',
version='1.0',
author='Pramod Arravind Byakod',
authour_email='Pramod.A.Byakod-1@ou.edu')
